package lab;

import java.util.Vector;

public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Vector<String> vector = new Vector<String>();
		vector.add("First Element");
		vector.add("Second Element");
		vector.add("Third Element");
		vector.add("Fourth Element");
		
		ComboBoxFrame comboBoxFrame = new ComboBoxFrame();
		comboBoxFrame.setVector(vector);
		comboBoxFrame.show();
		
		ListFrame listFrame = new ListFrame();
		listFrame.setVector(vector);
		listFrame.show();
	}

}
